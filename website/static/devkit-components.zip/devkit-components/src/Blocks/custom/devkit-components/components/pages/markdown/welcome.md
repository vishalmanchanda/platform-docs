# 🚧 Work in progress ahead

Hi!

We're phasing out Storybook in favor of a:
- WordPress sandbox, where you can play with all the blocks that come with DevKit
- simplified documentation page for built-in UI components

This will take some time, so some of the pages might be a bit rough around the edges as the content is transferred and re-formatted.

Documentation copy and component examples are also not final, and might change in the future.

Thank you for your patience.
