import React, { useState } from 'react';
import { MarkdownView } from '../markdown-view';
import { ItemShowcase } from '../item-showcase';
import { ColorPalette, ColorPicker, icons } from '@eightshift/frontend-libs/scripts';
import { CodeBlock } from '../code-block';

export const ColorPickers = () => {
	const [color, setColor] = useState();

	const customColors = [
		{
			name: 'Color 1',
			slug: 'color-1',
			color: '#FF11BB',
		},
		{
			name: 'Color 2',
			slug: 'color-2',
			color: '#0D3636',
		},
		{
			name: 'Transparent',
			slug: 'transparent',
			color: 'transparent',
		}
	];


	const styleColors = customColors.reduce((all, { slug, color }) => ({
		...all,
		[`--global-colors-${slug}`]: color,
	}), {});

	return (
		<>
			<MarkdownView
				content={`# Color pickers
				A set of color-picking controls, with a lot of config options.

				\`ColorPicker\` and \`ColorPalette\` are the main components`}
			/>

			<div className='devkit-component-config'>
				<ItemShowcase title='Simple picker'>
					<ColorPicker
						icon={icons.emptyCircle}
						label='Color'
						colors={customColors}
						value={color}
						onChange={(value) => setColor(value)}
						noBottomSpacing
						inlineLabel
					/>
				</ItemShowcase>

				<CodeBlock
					language='jsx'
					code={`<ColorPicker
	icon={icons.emptyCircle}
	label='Color'
	value={color}
	onChange={(value) => setColor(value)}
	inlineLabel
/>`}
				/>
			</div>

			<div className='devkit-component-config'>
				<ItemShowcase title='Border'>
					<ColorPicker
						colors={customColors}
						value={color}
						onChange={(value) => setColor(value)}
						noBottomSpacing
						border
					/>
				</ItemShowcase>

				<CodeBlock
					language='jsx'
					code={`<ColorPicker
	value={color}
	onChange={(value) => setColor(value)}
	border
/>`}
				/>
			</div>

			<div className='devkit-component-config'>
				<ItemShowcase title='Clearable'>
					<ColorPicker
						colors={customColors}
						value={color}
						onChange={(value) => setColor(value)}
						noBottomSpacing
						canReset
					/>
				</ItemShowcase>

				<CodeBlock
					language='jsx'
					code={`<ColorPicker
	value={color}
	onChange={(value) => setColor(value)}
	canReset
/>`}
				/>
			</div>

			<div className='devkit-component-config'>
				<ItemShowcase title='Expanded layout'>
					<ColorPicker
						colors={customColors}
						value={color}
						onChange={(value) => setColor(value)}
						noBottomSpacing
						expanded
					/>
				</ItemShowcase>

				<CodeBlock
					language='jsx'
					code={`<ColorPicker
	value={color}
	onChange={(value) => setColor(value)}
	expanded
/>`}
				/>
			</div>

			<div className='devkit-component-config'>
				<ItemShowcase title='Different color palette layout'>
					<ColorPicker
						colors={customColors}
						value={color}
						onChange={(value) => setColor(value)}
						noBottomSpacing
						colorPaletteLayout='list'
					/>
				</ItemShowcase>

				<CodeBlock
					language='jsx'
					code={`<ColorPicker
	value={color}
	onChange={(value) => setColor(value)}
	colorPaletteLayout='list'
/>`}
				/>
			</div>

			<div className='devkit-component-config'>
				<ItemShowcase title='Custom popover title'>
					<ColorPicker
						colors={customColors}
						value={color}
						onChange={(value) => setColor(value)}
						noBottomSpacing
						pickerPopupTitle='Pick me!'
					/>
				</ItemShowcase>

				<CodeBlock
					language='jsx'
					code={`<ColorPicker
	value={color}
	onChange={(value) => setColor(value)}
	pickerPopupTitle='Pick me!'
/>`}
				/>
			</div>

			<div className='devkit-component-config'>
				<ItemShowcase title='Searchable list'>
					<ColorPicker
						colors={customColors}
						value={color}
						onChange={(value) => setColor(value)}
						noBottomSpacing
						searchable
					/>
				</ItemShowcase>

				<CodeBlock
					language='jsx'
					code={`<ColorPicker
	value={color}
	onChange={(value) => setColor(value)}
	searchable
/>`}
				/>
			</div>

			<div className='devkit-component-config' style={styleColors}>
				<ItemShowcase title='Various types'>
					<div className='es-h-spaced'>
						<ColorPicker
							colors={customColors}
							value={color}
							onChange={(value) => setColor(value)}
							noBottomSpacing
							type='backgroundColor'
						/>
						<code>backgroundColor</code>
					</div>

					<div className='es-h-spaced'>
						<ColorPicker
							colors={customColors}
							value={color}
							onChange={(value) => setColor(value)}
							noBottomSpacing
							type='textColor'
						/>
						<code>textColor</code>
					</div>

					<div className='es-h-spaced'>
						<ColorPicker
							colors={customColors}
							value={color}
							onChange={(value) => setColor(value)}
							noBottomSpacing
							type='textHighlightColor'
						/>
						<code>textHighlightColor</code>
					</div>
				</ItemShowcase>

				<CodeBlock
					language='jsx'
					code={`<ColorPicker
	value={color}
	onChange={(value) => setColor(value)}
	type='backgroundColor' // or 'generic', or 'textColor', or 'textHighlightColor'
/>`}
				/>
			</div>

			<div className='devkit-component-config'>
				<ItemShowcase title='Custom icon'>
					<ColorPicker
						colors={customColors}
						value={color}
						onChange={(value) => setColor(value)}
						noBottomSpacing
						buttonIconOverride={icons.magicAlt}
						expanded
					/>
				</ItemShowcase>

				<CodeBlock
					language='jsx'
					code={`<ColorPicker
	value={color}
	onChange={(value) => setColor(value)}
	buttonIconOverride={icons.magicAlt}
	expanded
/>`}
				/>
			</div>

			<div className='es-w-full es-h-px es-bg-cool-gray-100' />

			<div className='devkit-component-config'>
				<ItemShowcase title='List of colors'>
					<ColorPalette
						colors={customColors}
						value={color}
						onChange={(value) => setColor(value)}
						noBottomSpacing
					/>
				</ItemShowcase>

				<CodeBlock
					language='jsx'
					code={`<ColorPalette
	value={color}
	onChange={(value) => setColor(value)}
/>`}
				/>
			</div>

			<div className='devkit-component-config'>
				<ItemShowcase title='Clearable list of colors'>
					<ColorPalette
						colors={customColors}
						value={color}
						onChange={(value) => setColor(value)}
						noBottomSpacing
						clearable
					/>
				</ItemShowcase>

				<CodeBlock
					language='jsx'
					code={`<ColorPalette
	value={color}
	onChange={(value) => setColor(value)}
	clearable
/>`}
				/>
			</div>
		</>
	);
};
