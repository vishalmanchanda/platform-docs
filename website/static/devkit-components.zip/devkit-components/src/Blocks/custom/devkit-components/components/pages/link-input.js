import React, { useState } from 'react';
import { MarkdownView } from '../markdown-view';
import { ItemShowcase } from '../item-showcase';
import { LinkInput, icons } from '@eightshift/frontend-libs/scripts';
import { CodeBlock } from '../code-block';

export const LinkInputDocs = () => {
	const [objData1, setObjData1] = useState({
		url: 'https://eightshift.com',
		newTab: false,
		isAnchor: false,
	});

	const [objData2, setObjData2] = useState({
		url: 'https://eightshift.com',
		isAnchor: false,
	});

	const [objData3, setObjData3] = useState({
		url: '#my-anchor',
		newTab: false,
		isAnchor: false,
	});

	const [objData4, setObjData4] = useState({
		url: 'https://eightshift.com',
		isAnchor: false,
	});

	const [objData5, setObjData5] = useState({
		url: 'https://eightshift.com',
		isAnchor: false,
	});

	const [objData6, setObjData6] = useState({
		url: '#my-anchor',
		isAnchor: false,
	});

	const data = [
		{ label: 'Eightshift', value: 'https://eightshift.com', metadata: { subtype: 'url' } },
		{ label: 'This is a demo post', value: 'https://your-website.com/demo-post', metadata: { subtype: 'post' } },
		{ label: 'Homepage', value: 'https://your-website.com/', metadata: { subtype: 'page' } },
		{ label: '2023 top secret report', value: 'https://your-website.com/2023-top-secret-report.pdf', metadata: { subtype: 'attachment' } },
		{ label: 'Services archive', value: 'https://your-website.com/services/', metadata: { subtype: 'category' } },
		{ label: 'Sign up form', value: 'https://your-website.com/forms/signup', metadata: { subtype: 'eightshift-forms' } },
	];

	const getData = (searchTerm) => {
		if (!searchTerm) {
			return data;
		}

		const filtered = data.filter(({ label, value }) =>
			label.toLowerCase().includes(searchTerm.toLowerCase().trim()) || value.toLowerCase().includes(searchTerm.toLowerCase().trim())
		);

		if (filtered.length > 0) {
			return filtered;
		}

		return data;
	};

	return (
		<>
			<MarkdownView
				content={`# Link input
				A inline URL editor that looks nice and fits into the other Gutenberg and Eightshift controls.`}
			/>

			<div className='devkit-component-config'>
				<ItemShowcase title='Default'>
					<LinkInput
						url={objData1.url}
						opensInNewTab={objData1.newTab}
						onChange={({ url, newTab, isAnchor }) => {
							setObjData1({ url, newTab, isAnchor });
						}}
						noBottomSpacing
						fetchSuggestions={getData}
					/>
				</ItemShowcase>

				<CodeBlock
					language='jsx'
					code={`<LinkInput
	url={buttonUrl}
	opensInNewTab={buttonIsNewTab}
	onChange={({ url, newTab, isAnchor }) => setAttributes({
		[getAttrKey('buttonUrl', attributes, manifest)]: url,
		[getAttrKey('buttonIsNewTab', attributes, manifest)]: newTab,
		[getAttrKey('buttonIsAnchor', attributes, manifest)]: isAnchor ?? false,
	})}
/>`}
				/>
			</div>

			<div className='devkit-component-config'>
				<ItemShowcase title='Disable "New tab" toggle'>
					<LinkInput
						url={objData2.url}
						onChange={({ url, isAnchor }) => {
							setObjData2({ url, isAnchor });
						}}
						noBottomSpacing
						hideOpensInNewTab
						fetchSuggestions={getData}
					/>
				</ItemShowcase>

				<CodeBlock
					language='jsx'
					code={`<LinkInput
	url={buttonUrl}
	onChange={({ url, isAnchor }) => setAttributes({
		[getAttrKey('buttonUrl', attributes, manifest)]: url,
		[getAttrKey('buttonIsAnchor', attributes, manifest)]: isAnchor ?? false,
	})}
	hideOpensInNewTab
/>`}
				/>
			</div>

			<div className='devkit-component-config'>
				<ItemShowcase title='Disable anchor indicator'>
					<LinkInput
						url={objData3.url}
						onChange={({ url, isAnchor }) => {
							setObjData3({ url, isAnchor });
						}}
						noBottomSpacing
						hideAnchorNotice
						hideOpensInNewTab
						fetchSuggestions={getData}
					/>
				</ItemShowcase>

				<CodeBlock
					language='jsx'
					code={`<LinkInput
	url={buttonUrl}
	onChange={({ url, isAnchor }) => setAttributes({
		[getAttrKey('buttonUrl', attributes, manifest)]: url,
		[getAttrKey('buttonIsAnchor', attributes, manifest)]: isAnchor ?? false,
	})}
	hideAnchorNotice
/>`}
				/>
			</div>

			<div className='devkit-component-config'>
				<ItemShowcase title='Disable clear button'>
					<LinkInput
						url={objData4.url}
						onChange={({ url, isAnchor }) => {
							setObjData4({ url, isAnchor });
						}}
						noBottomSpacing
						hideOpensInNewTab
						noDelete
						fetchSuggestions={getData}
					/>
				</ItemShowcase>

				<CodeBlock
					language='jsx'
					code={`<LinkInput
	url={buttonUrl}
	onChange={({ url, isAnchor }) => setAttributes({
		[getAttrKey('buttonUrl', attributes, manifest)]: url,
		[getAttrKey('buttonIsAnchor', attributes, manifest)]: isAnchor ?? false,
	})}
	noDelete
/>`}
				/>
			</div>

			<div className='devkit-component-config'>
				<ItemShowcase title='Custom clear icon'>
					<LinkInput
						url={objData5.url}
						onChange={({ url, isAnchor }) => {
							setObjData5({ url, isAnchor });
						}}
						noBottomSpacing
						hideOpensInNewTab
						removeIcon={icons.trashAlt}
					/>
				</ItemShowcase>

				<CodeBlock
					language='jsx'
					code={`<LinkInput
	url={buttonUrl}
	onChange={({ url, isAnchor }) => setAttributes({
		[getAttrKey('buttonUrl', attributes, manifest)]: url,
		[getAttrKey('buttonIsAnchor', attributes, manifest)]: isAnchor ?? false,
	})}
	removeIcon={icons.trashAlt}
/>`}
				/>
			</div>

			<div className='devkit-component-config'>
				<ItemShowcase title='Custom anchor icon'>
					<LinkInput
						url={objData6.url}
						onChange={({ url, isAnchor }) => {
							setObjData6({ url, isAnchor });
						}}
						noBottomSpacing
						hideOpensInNewTab
						anchorIcon={icons.magicAltFillTransparent}
					/>
				</ItemShowcase>

				<CodeBlock
					language='jsx'
					code={`<LinkInput
	url={buttonUrl}
	onChange={({ url, isAnchor }) => setAttributes({
		[getAttrKey('buttonUrl', attributes, manifest)]: url,
		[getAttrKey('buttonIsAnchor', attributes, manifest)]: isAnchor ?? false,
	})}
	anchorIcon={icons.magicAltFillTransparent}
/>`}
				/>
			</div>
		</>
	);
};
