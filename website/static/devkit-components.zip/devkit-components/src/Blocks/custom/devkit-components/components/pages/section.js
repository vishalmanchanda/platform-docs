import React, { useState } from 'react';
import { MarkdownView } from '../markdown-view';
import { ItemShowcase } from '../item-showcase';
import { Section, icons } from '@eightshift/frontend-libs/scripts';
import { Button } from '@wordpress/components';
import { CodeBlock } from '../code-block';

export const SectionDocs = () => {
	const [visible, setVisible] = useState(true);

	return (
		<>
			<MarkdownView
				content={`# Section
				A component that makes option panel compartmentalization easy.`}
			/>

			<div className='devkit-component-config'>
				<ItemShowcase title='Default'>
					<Section
						icon={icons.emptyCircle}
						label='Section'
						noBottomSpacing
					>
						<div className='es-w-full es-h-24 es-bg-cool-gray-100 es-rounded-1' />
					</Section>
				</ItemShowcase>

				<CodeBlock
					language='jsx'
					code={`<Section
	icon={icons.emptyCircle}
	label='Section'
>
	...
</Section>`}
				/>
			</div>

			<div className='devkit-component-config'>
				<ItemShowcase title='Subtitle'>
					<Section
						icon={icons.emptyCircle}
						label='Section'
						subtitle='Subtitle'
						noBottomSpacing
					>
						<div className='es-w-full es-h-24 es-bg-cool-gray-100 es-rounded-1' />
					</Section>
				</ItemShowcase>

				<CodeBlock
					language='jsx'
					code={`<Section
	icon={icons.emptyCircle}
	label='Section'
	subtitle='Subtitle'
>
	...
</Section>`}
				/>
			</div>

			<div className='devkit-component-config'>
				<ItemShowcase title='Collapsable'>
					<Section
						icon={icons.emptyCircle}
						label='Section'
						noBottomSpacing
						collapsable
					>
						<div className='es-w-full es-h-24 es-bg-cool-gray-100 es-rounded-1' />
					</Section>
				</ItemShowcase>

				<CodeBlock
					language='jsx'
					code={`<Section
	icon={icons.emptyCircle}
	label='Section'
	collapsable
>
	...
</Section>`}
				/>
			</div>

			<div className='devkit-component-config'>
				<ItemShowcase title='Text only'>
					<Section
						label='Section'
						noBottomSpacing
					>
						<div className='es-w-full es-h-24 es-bg-cool-gray-100 es-rounded-1' />
					</Section>
				</ItemShowcase>

				<CodeBlock
					language='jsx'
					code={`<Section
	label='Section'
>
	...
</Section>`}
				/>
			</div>

			<div className='devkit-component-config'>
				<ItemShowcase title='Text and subtitle'>
					<Section
						label='Section'
						subtitle='Subtitle'
						noBottomSpacing
					>
						<div className='es-w-full es-h-24 es-bg-cool-gray-100 es-rounded-1' />
					</Section>
				</ItemShowcase>

				<CodeBlock
					language='jsx'
					code={`<Section
	label='Section'
	subtitle='Subtitle'
>
	...
</Section>`}
				/>
			</div>

			<div className='devkit-component-config'>
				<ItemShowcase
					title='Conditional rendering'
					demoContainerClass='es-h-44'
					additionalPanels={[{
						title: 'Actions',
						content: (
							<Button
								onClick={() => setVisible(!visible)}
								// eslint-disable-next-line max-len
								className='es-w-14 es-content-center es-rounded-1.5! es-border-cool-gray-300 es-hover-border-cool-gray-500 es-hover-color-cool-gray-800! es-transition'
							>
								{visible ? 'Hide' : 'Show'}
							</Button>
						),
					}]}
				>
					<Section
						icon={icons.emptyCircle}
						label='Section'
						noBottomSpacing
						showIf={visible}
					>
						<div className='es-w-full es-h-27 es-bg-cool-gray-100 es-rounded-1' />
					</Section>
				</ItemShowcase>

				<CodeBlock
					language='jsx'
					code={`<Section
	icon={icons.emptyCircle}
	label='Section'
	showIf={visible}
>
	...
</Section>`}
				/>
			</div>
		</>
	);
};
