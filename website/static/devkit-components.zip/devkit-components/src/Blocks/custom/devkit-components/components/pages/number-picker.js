import React, { useState } from 'react';
import { MarkdownView } from '../markdown-view';
import { ItemShowcase } from '../item-showcase';
import { icons, NumberPicker } from '@eightshift/frontend-libs/scripts';
import { CodeBlock } from '../code-block';

export const NumberPickerDocs = () => {
	const [value, setValue] = useState(8);


	const baseProps = {
		min: 1,
		max: 100,
		noBottomSpacing: true,
		label: 'Picker',
		icon: icons.emptyCircle,
	};

	return (
		<>
			<MarkdownView
				content={`# NumberPicker
				🚧 Work in progress`}
			/>

			<div className='es-display-flex es-flex-wrap es-gap-5!'>
				<ItemShowcase title='Basic component'>
					<NumberPicker
						{...baseProps}
						value={value}
						onChange={(value) => setValue(value)}
					/>
				</ItemShowcase>

				<ItemShowcase title='Extra controls'>
					<NumberPicker
						{...baseProps}
						value={value}
						onChange={(value) => setValue(value)}
						extraButton={<span className='es-line-h-0 es-color-admin-accent'>{icons.magicAltFillTransparent}</span>}
					/>
				</ItemShowcase>

				<ItemShowcase title='Prefix'>
					<NumberPicker
						{...baseProps}
						value={value}
						onChange={(value) => setValue(value)}
						prefix='€'
					/>
				</ItemShowcase>

				<ItemShowcase title='Suffix'>
					<NumberPicker
						{...baseProps}
						value={value}
						onChange={(value) => setValue(value)}
						suffix='%'
					/>
				</ItemShowcase>
			</div>

			<CodeBlock
				language='jsx'
				code={`<NumberPicker
	icon={icons.emptyCircle}
	label='Picker'
	value={value}
	onChange={(value) => setValue(value)}
	min={1}
	max={100}

	// ----------------------------------------------------------------
	// Other examples, each example includes the props above this text.
	// ----------------------------------------------------------------

	// Extra controls
	extraButton={icons.magicAltFillTransparent}

	// Prefix
	prefix='€'

	// Suffix
	suffix='%'
/>`}
			/>

		</>
	);
};
