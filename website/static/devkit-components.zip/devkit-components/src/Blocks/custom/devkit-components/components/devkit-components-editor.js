import React, { useState } from 'react';
import { OptionSelector } from '@eightshift/frontend-libs/scripts';
import { MarkdownView } from './markdown-view';
import {
	Icons,
	AdvancedColorPickerDocs,
	AnimatedContentVisibilityDocs,
	BaseControlDocs,
	CollapsableDocs,
	ColorPickers,
	SelectDocs,
	SliderDocs,
	FancyDividerDocs,
	IconLabelDocs,
	ToggleDocs,
	NotificationDocs,
	LinkInputDocs,
	MatrixAlignControlDocs,
	MenuDocs,
	NumberPickerDocs,
	OptionSelectorDocs,
	PopoverWithTriggerDocs,
	PresetPickerDocs,
	ReOrderableDocs,
	ResponsiveDocs,
	SectionDocs,
	ServerSideRenderDocs,
	UseToggleDocs,
} from './pages';

export const DevkitComponentsEditor = () => {
	const [activeTab, setActiveTab] = useState(0);

	const iconTabs = [
		'Icons',
		'UI icons',
		'Block icons',
		'Icon animation',
	];

	const tabs = [
		'AdvancedColorPicker',
		'AnimatedContentVisibility',
		'Control',
		'BlockInserter',
		'Collapsable',
		'Color pickers',
		'Select',
		'Slider',
		'FancyDivider',
		'IconLabel',
		'Toggles and TileButton',
		'Notification',
		'LinkInput',
		'MatrixAlignControl',
		'Menu',
		'NumberPicker',
		'OptionSelector',
		'PopoverWithTrigger',
		'PresetPicker',
		'ReOrderable and Repeater',
		'Responsive components',
		'Section',
		'ServerSideRender',
		'UseToggle',
	];

	const pageContent = {
		0: <MarkdownView filename='welcome' prose />,
		1: <Icons page='intro' />,
		2: <Icons page='ui' />,
		3: <Icons page='block' />,
		4: <Icons page='animations' />,
		5: <AdvancedColorPickerDocs />,
		6: <AnimatedContentVisibilityDocs />,
		7: <BaseControlDocs />,
		8: <MarkdownView filename='block-inserter' />,
		9: <CollapsableDocs />,
		10: <ColorPickers />,
		11: <SelectDocs />,
		12: <SliderDocs />,
		13: <FancyDividerDocs />,
		14: <IconLabelDocs />,
		15: <ToggleDocs />,
		16: <NotificationDocs />,
		17: <LinkInputDocs />,
		18: <MatrixAlignControlDocs />,
		19: <MenuDocs />,
		20: <NumberPickerDocs />,
		21: <OptionSelectorDocs />,
		22: <PopoverWithTriggerDocs />,
		23: <PresetPickerDocs />,
		24: <ReOrderableDocs />,
		25: <ResponsiveDocs />,
		26: <SectionDocs />,
		27: <ServerSideRenderDocs />,
		28: <UseToggleDocs />,
	};

	return (
		<div className='devkit-component-listing-container es-size-full es-p-8'>
			<div className='es-v-spaced es-position-sticky es-top-10 es-h-fit'>
				<OptionSelector
					value={activeTab}
					onChange={(value) => setActiveTab(value)}
					alignment='vertical'
					options={[{ value: 0, label: 'Welcome' }]}
					border='none'
					compactButtons
					additionalButtonClass='es-rounded-1.5'
				/>

				<OptionSelector
					value={activeTab}
					onChange={(value) => setActiveTab(value)}
					alignment='vertical'
					options={iconTabs.map((tab, index) => ({ value: index + 1, label: tab }))}
					border='none'
					compactButtons
					additionalButtonClass='es-rounded-1.5'
				/>

				<OptionSelector
					value={activeTab}
					onChange={(value) => setActiveTab(value)}
					alignment='vertical'
					options={tabs.map((tab, index) => ({ value: index + iconTabs.length + 1, label: tab }))}
					border='none'
					compactButtons
					additionalButtonClass='es-rounded-1.5'
				/>
			</div>

			<div className='es-v-spaced es-gap-8! es-py-20'>
				{pageContent?.[activeTab]}
			</div>
		</div>
	);
};
