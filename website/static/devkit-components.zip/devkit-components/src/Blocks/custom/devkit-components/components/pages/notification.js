import React from 'react';
import { MarkdownView } from '../markdown-view';
import { ItemShowcase } from '../item-showcase';
import { Notification, icons } from '@eightshift/frontend-libs/scripts';
import { CodeBlock } from '../code-block';

export const NotificationDocs = () => {

	return (
		<>
			<MarkdownView
				content={`# Notification
				A simple alert.`}
			/>

			<div className='devkit-component-config'>
				<ItemShowcase title='Built-in styles'>
					<Notification
						text='Notification title'
						subtitle='Description text below the title'
					/>

					<Notification
						text='Notification title'
						subtitle='Description text below the title'
						type='error'
					/>

					<Notification
						text='Notification title'
						subtitle='Description text below the title'
						type='info'
					/>

					<Notification
						text='Notification title'
						subtitle='Description text below the title'
						type='success'
					/>

					<Notification
						text='Notification title'
						subtitle='Description text below the title'
						type='warning'
						noBottomSpacing
					/>
				</ItemShowcase>

				<CodeBlock
					language='jsx'
					code={`<Notification
	text='Notification title'
	subtitle='Description text below the title'
/>

<Notification
	text='Notification title'
	subtitle='Description text below the title'
	type='error'
/>

<Notification
	text='Notification title'
	subtitle='Description text below the title'
	type='info'
/>

<Notification
	text='Notification title'
	subtitle='Description text below the title'
	type='success'
/>

<Notification
	text='Notification title'
	subtitle='Description text below the title'
	type='warning'
/>`}
				/>
			</div>

			<div className='devkit-component-config'>
				<ItemShowcase title='Custom icon'>
					<Notification
						text='Notification title'
						subtitle='Description text below the title'
						iconOverride={icons.emptyCircle}
						noBottomSpacing
					/>
				</ItemShowcase>

				<CodeBlock
					language='jsx'
					code={`<Notification
	text='Notification title'
	subtitle='Description text below the title'
	iconOverride={icons.emptyCircle}
/>`}
				/>
			</div>

			<div className='devkit-component-config'>
				<ItemShowcase title='Custom classes'>
					<Notification
						text='Notification title'
						subtitle='Description text below the title'
						additionalClasses='es-color-red-500!'
						noBottomSpacing
					/>
				</ItemShowcase>

				<CodeBlock
					language='jsx'
					code={`<Notification
	text='Notification title'
	subtitle='Description text below the title'
	additionalClasses='es-color-red-500!'
/>`}
				/>
			</div>
		</>
	);
};
