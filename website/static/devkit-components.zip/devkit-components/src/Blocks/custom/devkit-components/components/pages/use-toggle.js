import React, { useState } from 'react';
import { MarkdownView } from '../markdown-view';
import { ItemShowcase } from '../item-showcase';
import { UseToggle } from '@eightshift/frontend-libs/scripts';
import { CodeBlock } from '../code-block';

export const UseToggleDocs = () => {
	const [v1, setV1] = useState(false);
	const [v2, setV2] = useState(false);

	return (
		<>
			<MarkdownView
				content={`# UseToggle
				A component that allows toggling pieces of content.`}
			/>

			<div className='devkit-component-config'>
				<ItemShowcase title='Default'>
					<UseToggle
						label='UseToggle label'
						checked={v1}
						onChange={(value) => setV1(value)}
						noBottomSpacing
					>
						<div className='es-w-full es-h-32 es-bg-cool-gray-100 es-rounded-1' />
					</UseToggle>
				</ItemShowcase>

				<CodeBlock
					language='jsx'
					code={`<UseToggle
	label='UseToggle label'
	checked={current}
	onChange={(value) => setCurrent(value)}
>
	...
</UseToggle>`}
				/>
			</div>

			<div className='devkit-component-config'>
				<ItemShowcase title='No expand button'>
					<UseToggle
						label='UseToggle label'
						checked={v2}
						onChange={(value) => setV2(value)}
						noBottomSpacing
						noExpandButton
					>
						<div className='es-w-full es-h-32 es-bg-cool-gray-100 es-rounded-1' />
					</UseToggle>
				</ItemShowcase>

				<CodeBlock
					language='jsx'
					code={`<UseToggle
	label='UseToggle label'
	checked={current}
	onChange={(value) => setCurrent(value)}
	noExpandButton
>
	...
</UseToggle>`}
				/>
			</div>

			<div className='devkit-component-config'>
				<ItemShowcase title='No use toggle'>
					<UseToggle
						label='UseToggle label'
						checked
						noBottomSpacing
						noUseToggle
					>
						<div className='es-w-full es-h-32 es-bg-cool-gray-100 es-rounded-1' />
					</UseToggle>
				</ItemShowcase>

				<CodeBlock
					language='jsx'
					code={`<UseToggle
	label='UseToggle label'
	noUseToggle
>
	...
</UseToggle>`}
				/>
			</div>
		</>
	);
};
