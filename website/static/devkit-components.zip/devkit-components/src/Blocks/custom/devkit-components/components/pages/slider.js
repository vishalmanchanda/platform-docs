import React, { useState } from 'react';
import { MarkdownView } from '../markdown-view';
import { ItemShowcase } from '../item-showcase';
import {
	ColumnConfigSlider,
	icons,
	RangeSlider,
	Slider,
} from '@eightshift/frontend-libs/scripts';
import { CodeBlock } from '../code-block';

export const SliderDocs = () => {
	const [value, setValue] = useState(8);

	const [rangeValue, setRangeValue] = useState([10, 30]);
	const [rangeValue2, setRangeValue2] = useState([10, 30, 50]);

	const [colCnfValue, setColCnfValue] = useState([2, 4]);

	const baseSliderProps = {
		min: 1,
		max: 100,
		noBottomSpacing: true,
		label: 'Slider',
		icon: icons.emptyCircle,
	};

	return (
		<>
			<MarkdownView
				content={`# Sliders
				🚧 Work in progress`}
			/>

			<h2>Simple slider</h2>

			<div className='es-display-flex es-flex-wrap es-gap-5!'>
				<ItemShowcase title='Basic slider'>
					<Slider
						{...baseSliderProps}
						value={value}
						onChange={(value) => setValue(value)}
					/>
				</ItemShowcase>

				<ItemShowcase title='Auto-generated marks'>
					<Slider
						{...baseSliderProps}
						value={value}
						onChange={(value) => setValue(value)}
						marks
					/>
				</ItemShowcase>

				<ItemShowcase title='Additions'>
					<Slider
						{...baseSliderProps}
						value={value}
						onChange={(value) => setValue(value)}
						leftAddition={icons.emptyRect}
						rightAddition={icons.emptyRect}
					/>
				</ItemShowcase>

				<ItemShowcase title='Value display'>
					<Slider
						{...baseSliderProps}
						value={value}
						onChange={(value) => setValue(value)}
						valueDisplay
					/>
				</ItemShowcase>

				<ItemShowcase title='Custom value display'>
					<Slider
						{...baseSliderProps}
						value={value}
						onChange={(value) => setValue(value)}
						valueDisplay
						// eslint-disable-next-line max-len
						valueDisplayElement={<span style={{ color: 'purple', fontFamily: 'serif', fontWeight: 'bold', fontSize: '1rem' }}><small>Value:</small> {value}</span>}
					/>
				</ItemShowcase>

				<ItemShowcase title='Input field'>
					<Slider
						{...baseSliderProps}
						value={value}
						onChange={(value) => setValue(value)}
						inputField
					/>
				</ItemShowcase>

				<ItemShowcase title='Reversed slider'>
					<Slider
						{...baseSliderProps}
						value={value}
						onChange={(value) => setValue(value)}
						reverse
					/>
				</ItemShowcase>

				<ItemShowcase title='Disabled'>
					<Slider
						{...baseSliderProps}
						value={value}
						onChange={(value) => setValue(value)}
						marks
						inputField
						disabled
					/>
				</ItemShowcase>

				<ItemShowcase title='Custom step value'>
					<Slider
						{...baseSliderProps}
						value={value}
						onChange={(value) => setValue(value)}
						step={2}
					/>
				</ItemShowcase>

				<ItemShowcase title='Dots'>
					<Slider
						{...baseSliderProps}
						value={value}
						onChange={(value) => setValue(value)}
						marks='dots'
						step={10}
					/>
				</ItemShowcase>

				<ItemShowcase title='Custom track color'>
					<Slider
						{...baseSliderProps}
						value={value}
						onChange={(value) => setValue(value)}
						trackColor='red'
					/>
				</ItemShowcase>

				<ItemShowcase title='Custom rail color'>
					<Slider
						{...baseSliderProps}
						value={value}
						onChange={(value) => setValue(value)}
						railColor='green'
					/>
				</ItemShowcase>

				<ItemShowcase title='Custom track and rail color'>
					<Slider
						{...baseSliderProps}
						value={value}
						onChange={(value) => setValue(value)}
						trackColor='linear-gradient(270deg, yellow, orange)'
						railColor='linear-gradient(90deg, #00DBDE 0%, #FC00FF 100%)'
					/>
				</ItemShowcase>

				<ItemShowcase title='Custom handle color'>
					<Slider
						{...baseSliderProps}
						value={value}
						onChange={(value) => setValue(value)}
						handleColor='linear-gradient(-45deg, red, orange)'
					/>
				</ItemShowcase>

				<ItemShowcase title='Custom mark colors'>
					<Slider
						{...baseSliderProps}
						value={value}
						onChange={(value) => setValue(value)}
						marks
						activeMarkColor='red'
						inactiveMarkColor='green'
					/>
				</ItemShowcase>

				<ItemShowcase title='Custom start point'>
					<Slider
						{...baseSliderProps}
						value={value}
						onChange={(value) => setValue(value)}
						startPoint={50}
					/>
				</ItemShowcase>

				<ItemShowcase title='Discrete value'>
					<Slider
						{...baseSliderProps}
						value={value}
						onChange={(value) => setValue(value)}
						discrete
						marks
					/>
				</ItemShowcase>
			</div>

			<CodeBlock
				language='jsx'
				code={`<Slider
	icon={icons.emptyCircle}
	label='Slider'
	value={value}
	onChange={(value) => setValue(value)}
	min={1}
	max={100}

	// ----------------------------------------------------------------
	// Other examples, each example includes the props above this text.
	// ----------------------------------------------------------------

	// Auto-generated marks
	marks

	// Additions
	leftAddition={icons.emptyRect}
	rightAddition={icons.emptyRect}

	// Value display
	valueDisplay

	// Custom value display
	valueDisplayElement={<span style={{ color: 'purple', fontFamily: 'serif', fontWeight: 'bold', fontSize: '1rem' }}><small>Value:</small> {value}</span>}

	// Input field
	inputField

	// Reversed slider
	reverse

	// Custom step
	step={2}

	// Dots
	marks='dots'
	step={10}

	// Custom track color
	trackColor='red'

	// Custom rail color
	railColor='green'

	// Custom track and rail color
	trackColor='linear-gradient(270deg, yellow, orange)'
	railColor='linear-gradient(90deg, #00DBDE 0%, #FC00FF 100%)'

	// Custom handle color
	handleColor='linear-gradient(-45deg, red, orange)'

	// Custom mark color
	marks
	activeMarkColor='red'
	inactiveMarkColor='green'

	// Custom start point
	startPoint={50}

	// Discrete values (instead of continuous)
	discrete
/>`}
			/>

			<h2>Range slider</h2>
			<div className='es-display-flex es-flex-wrap es-gap-5!'>
				<ItemShowcase title='Basic slider'>
					<RangeSlider
						{...baseSliderProps}
						value={rangeValue}
						onChange={(value) => setRangeValue(value)}
					/>
				</ItemShowcase>

				<ItemShowcase title='Marks'>
					<RangeSlider
						{...baseSliderProps}
						value={rangeValue}
						onChange={(value) => setRangeValue(value)}
						marks
					/>
				</ItemShowcase>

				<ItemShowcase title='Value display'>
					<RangeSlider
						{...baseSliderProps}
						value={rangeValue}
						onChange={(value) => setRangeValue(value)}
						valueDisplay
					/>
				</ItemShowcase>

				<ItemShowcase title='Input fields'>
					<RangeSlider
						{...baseSliderProps}
						value={rangeValue}
						onChange={(value) => setRangeValue(value)}
						inputField
					/>
				</ItemShowcase>

				<ItemShowcase title='Draggable track'>
					<RangeSlider
						{...baseSliderProps}
						value={rangeValue}
						onChange={(value) => setRangeValue(value)}
						draggableTrack
					/>
				</ItemShowcase>

				<ItemShowcase title='Multiple ranges'>
					<RangeSlider
						{...baseSliderProps}
						value={rangeValue2}
						onChange={(value) => setRangeValue2(value)}
					/>
				</ItemShowcase>

				<ItemShowcase title='Pushable values'>
					<RangeSlider
						{...baseSliderProps}
						value={rangeValue}
						onChange={(value) => setRangeValue(value)}
						pushable
					/>
				</ItemShowcase>

				<ItemShowcase title='Pushable ranges with minimum distance between handles'>
					<RangeSlider
						{...baseSliderProps}
						value={rangeValue}
						onChange={(value) => setRangeValue(value)}
						pushable={10}
					/>
				</ItemShowcase>

				<ItemShowcase title='Non-crossable ranges'>
					<RangeSlider
						{...baseSliderProps}
						value={rangeValue}
						onChange={(value) => setRangeValue(value)}
						noCross
					/>
				</ItemShowcase>

				<ItemShowcase title='Discrete values'>
					<RangeSlider
						{...baseSliderProps}
						value={rangeValue}
						onChange={(value) => setRangeValue(value)}
						discrete
					/>
				</ItemShowcase>
			</div>

			<CodeBlock
				language='jsx'
				code={`// Example value: [10, 30]

<RangeSlider
	icon={icons.emptyCircle}
	label='Slider'
	value={value}
	onChange={(value) => setValue(value)}
	min={1}
	max={100}

	// ----------------------------------------------------------------
	// Other examples, each example includes the props above this text.
	// ----------------------------------------------------------------

	// Draggable track
	draggableTrack

	// Pushable values
	pushable

	// Pushable ranges with minimum distance between handles
	pushable={10}

	// Non-crossable ranges
	noCross
/>`}
			/>

			<h2>Column configurator slider</h2>

			<div className='es-display-flex es-flex-wrap es-gap-5!'>
				<ItemShowcase title='Basic slider'>
					<ColumnConfigSlider
						noBottomSpacing
						label='Slider'
						icon={icons.emptyCircle}
						value={colCnfValue}
						onChange={(value) => setColCnfValue(value)}
					/>
				</ItemShowcase>

				<ItemShowcase title='No offset handle'>
					<ColumnConfigSlider
						noBottomSpacing
						label='Slider'
						icon={icons.emptyCircle}
						value={colCnfValue}
						onChange={(value) => setColCnfValue(value)}
						noOffsetHandle
					/>
				</ItemShowcase>

				<ItemShowcase title='No width handle'>
					<ColumnConfigSlider
						noBottomSpacing
						label='Slider'
						icon={icons.emptyCircle}
						value={colCnfValue}
						onChange={(value) => setColCnfValue(value)}
						noWidthHandle
					/>
				</ItemShowcase>

				<ItemShowcase title='No handles'>
					<ColumnConfigSlider
						noBottomSpacing
						label='Slider'
						icon={icons.emptyCircle}
						value={colCnfValue}
						onChange={(value) => setColCnfValue(value)}
						noOffsetHandle
						noWidthHandle
					/>
				</ItemShowcase>
			</div>

			<CodeBlock
				language='jsx'
				code={`// Example value: [10, 30]

<ColumnConfigSlider
	icon={icons.emptyCircle}
	label='Slider'
	value={value}
	onChange={(value) => setValue(value)}

	// ----------------------------------------------------------------
	// Other examples, each example includes the props above this text.
	// ----------------------------------------------------------------

	// No offset handle
	noOffsetHandle

	// No width handle
	noWidthHandle
/>`}
			/>

		</>
	);
};
