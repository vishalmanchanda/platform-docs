import React from 'react';
import { MarkdownView } from '../markdown-view';
import { ItemShowcase } from '../item-showcase';
import { FancyDivider, icons } from '@eightshift/frontend-libs/scripts';
import { CodeBlock } from '../code-block';

export const FancyDividerDocs = () => {
	return (
		<>
			<MarkdownView
				content={`# FancyDivider
				A fancy... divider.`}
			/>

			<div className='devkit-component-config'>
				<ItemShowcase title='Text-only divider'>
					<FancyDivider label='Divider' noBottomSpacing />
				</ItemShowcase>

				<CodeBlock
					language='jsx'
					code="<FancyDivider label='Divider' />"
				/>
			</div>

			<div className='devkit-component-config'>
				<ItemShowcase title='Divider with icon'>
					<FancyDivider label='Divider' icon={icons.magicAltFillTransparent} noBottomSpacing />
				</ItemShowcase>

				<CodeBlock
					language='jsx'
					code="<FancyDivider icon={icons.magicAltFillTransparent} label='Divider' />"
				/>
			</div>
		</>
	);
};
