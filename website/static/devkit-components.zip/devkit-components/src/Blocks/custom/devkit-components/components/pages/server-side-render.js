import React from 'react';
import { MarkdownView } from '../markdown-view';
import { ItemShowcase } from '../item-showcase';
import { ServerSideRender } from '@eightshift/frontend-libs/scripts';
import { CodeBlock } from '../code-block';

export const ServerSideRenderDocs = () => {
	return (
		<>
			<MarkdownView
				content={`# Server-side render
				A component that allows rendering blocks in the editor.

				Useful for showing previews for more complex blocks, or blocks requiring WP Query or similar.`}
			/>

			<div className='devkit-component-config'>
				<ItemShowcase title='Default' demoContainerClass='es-h-44 es-position-relative'>
					<ServerSideRender
						block='eightshift-boilerplate/demo-block'
						attributes={{
							demoBlockText: 'Hello from the rendered block',
							// wrapperUse: false
						}}
					/>
				</ItemShowcase>

				<CodeBlock
					language='jsx'
					code={`<ServerSideRender
	block='eightshift-boilerplate/paragraph'
	attributes={{
		...
	}}
/>`}
				/>
			</div>
		</>
	);
};
