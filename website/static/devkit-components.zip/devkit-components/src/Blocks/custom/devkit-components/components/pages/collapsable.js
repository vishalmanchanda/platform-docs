import React from 'react';
import { MarkdownView } from '../markdown-view';
import { ItemShowcase } from '../item-showcase';
import { Collapsable, icons } from '@eightshift/frontend-libs/scripts';
import { CodeBlock } from '../code-block';

export const CollapsableDocs = () => {
	return (
		<>
			<MarkdownView
				content={`# Collapsable
				Ever wanted an accordion in your options panel? Well, this is close.
				\`Collapsable\` allows you to group child elements into a collapsable area, and provides a very simple accordion-like implementation.`}
			/>

			<div className='devkit-component-config'><ItemShowcase title='Base control'>
				<Collapsable label='Label' icon={icons.emptyCircle} noBottomSpacing>
					<div className='es-w-full es-h-24 es-bg-cool-gray-100 es-rounded-1' />
				</Collapsable>
			</ItemShowcase>

				<CodeBlock
					language='jsx'
					code={`<Collapsable label='Label' icon={icons.emptyCircle}>
	...
</Collapsable>`}
				/>
			</div>

			<div className='devkit-component-config'><ItemShowcase title='Actions'>
				<Collapsable
					label='Label'
					icon={icons.emptyCircle}
					actions={<div className='es-h-spaced'>{icons.emptyRect}{icons.emptyRect}{icons.emptyRect}</div>}
					noBottomSpacing
				>
					<div className='es-w-full es-h-24 es-bg-cool-gray-100 es-rounded-1' />
				</Collapsable>
			</ItemShowcase>

				<CodeBlock
					language='jsx'
					code={`<Collapsable label='Label' icon={icons.emptyCircle} actions={...}>
	...
</Collapsable>`}
				/>
			</div>

			<div className='devkit-component-config'><ItemShowcase title='Actions (always visible)'>
				<Collapsable
					label='Label'
					icon={icons.emptyCircle}
					actions={<div className='es-h-spaced'>{icons.emptyRect}{icons.emptyRect}{icons.emptyRect}</div>}
					keepActionsOnExpand
					noBottomSpacing
				>
					<div className='es-w-full es-h-24 es-bg-cool-gray-100 es-rounded-1' />
				</Collapsable>
			</ItemShowcase>

				<CodeBlock
					language='jsx'
					code={`<Collapsable label='Label' icon={icons.emptyCircle} actions={...} keepActionsOnExpand>
	...
</Collapsable>`}
				/>
			</div>

			<div className='devkit-component-config'><ItemShowcase title='Subtitle'>
				<Collapsable label='Label' icon={icons.emptyCircle} subtitle='Subtitle' noBottomSpacing>
					<div className='es-w-full es-h-24 es-bg-cool-gray-100 es-rounded-1' />
				</Collapsable>
			</ItemShowcase>

				<CodeBlock
					language='jsx'
					code={`<Collapsable label='Label' subtitle='Subtitle' icon={icons.emptyCircle}>
	...
</Collapsable>`}
				/>
			</div>
		</>
	);
};
