# BlockInserter

A replacement for the default Gutenberg inserter, whose styling can vary between WP versions.

## Usage

```jsx
<InnerBlocks
	allowedBlocks={(typeof columnsAllowedBlocks === 'undefined') || columnsAllowedBlocks}
	orientation='horizontal'
	renderAppender={() => <BlockInserter clientId={clientId} />}
/>
```
