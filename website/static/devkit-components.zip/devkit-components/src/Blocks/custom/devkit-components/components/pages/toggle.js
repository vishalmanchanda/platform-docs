import React, { useState } from 'react';
import { MarkdownView } from '../markdown-view';
import { ItemShowcase } from '../item-showcase';
import { Toggle, TileButton, icons } from '@eightshift/frontend-libs/scripts';
import { CodeBlock } from '../code-block';

export const ToggleDocs = () => {
	const [v1, setV1] = useState(false);
	const [v2, setV2] = useState(false);
	const [v3, setV3] = useState(false);
	const [v4, setV4] = useState(false);
	const [v5, setV5] = useState(false);
	const [v6, setV6] = useState(false);

	return (
		<>
			<MarkdownView
				content={`# Toggles
				A collection of toggle controls.`}
			/>

			<div className='devkit-component-config'>
				<ItemShowcase title='Toggle switch'>
					<Toggle
						icon={icons.emptyCircle}
						label='Toggle control'
						checked={v1}
						onChange={(value) => setV1(value)}
						noBottomSpacing
					/>
				</ItemShowcase>

				<CodeBlock
					language='jsx'
					code={`<Toggle
	icon={icons.emptyCircle}
	label='Toggle control'
	checked={current}
	onChange={(value) => setCurrent(value)}
/>`}
				/>
			</div>

			<div className='devkit-component-config'>
				<ItemShowcase title='Toggle switch with help'>
					<Toggle
						icon={icons.emptyCircle}
						label='Toggle control'
						checked={v2}
						onChange={(value) => setV2(value)}
						noBottomSpacing
						help='This is the help text'
					/>
				</ItemShowcase>

				<CodeBlock
					language='jsx'
					code={`<Toggle
	icon={icons.emptyCircle}
	label='Toggle control'
	checked={current}
	onChange={(value) => setCurrent(value)}
	help='This is the help text'
/>`}
				/>
			</div>

			<div className='devkit-component-config'>
				<ItemShowcase title='Toggle switch with inline help'>
					<Toggle
						icon={icons.emptyCircle}
						label='Toggle control'
						checked={v3}
						onChange={(value) => setV3(value)}
						noBottomSpacing
						help='This is the help text'
						inlineHelp
					/>
				</ItemShowcase>

				<CodeBlock
					language='jsx'
					code={`<Toggle
	icon={icons.emptyCircle}
	label='Toggle control'
	checked={current}
	onChange={(value) => setCurrent(value)}
	help='This is the help text'
	inlineHelp
/>`}
				/>
			</div>

			<div className='devkit-component-config'>
				<ItemShowcase title='Button'>
					<Toggle
						icon={icons.emptyCircle}
						label='Toggle control'
						checked={v4}
						onChange={(value) => setV4(value)}
						noBottomSpacing
						type='button'
					/>
				</ItemShowcase>

				<CodeBlock
					language='jsx'
					code={`<Toggle
	icon={icons.emptyCircle}
	label='Toggle control'
	checked={current}
	onChange={(value) => setCurrent(value)}
	type='button'
/>`}
				/>
			</div>

			<div className='devkit-component-config'>
				<ItemShowcase title='Icon button'>
					<Toggle
						icon={icons.emptyCircle}
						label='Toggle control'
						checked={v5}
						onChange={(value) => setV5(value)}
						noBottomSpacing
						type='iconButton'
					/>
				</ItemShowcase>

				<CodeBlock
					language='jsx'
					code={`<Toggle
	icon={icons.emptyCircle}
	label='Toggle control'
	checked={current}
	onChange={(value) => setCurrent(value)}
	type='iconButton'
/>`}
				/>
			</div>

			<div className='devkit-component-config'>
				<ItemShowcase title='Tile button'>
					<Toggle
						icon={icons.emptyCircle}
						label='Toggle control'
						checked={v6}
						onChange={(value) => setV6(value)}
						noBottomSpacing
						type='tileButton'
					/>
				</ItemShowcase>

				<CodeBlock
					language='jsx'
					code={`<Toggle
	icon={icons.emptyCircle}
	label='Toggle control'
	checked={current}
	onChange={(value) => setCurrent(value)}
	type='tileButton'
/>`}
				/>
			</div>

			<div className='es-w-full es-h-px es-bg-cool-gray-100' />

			<h2>TileButton</h2>

			<div className='devkit-component-config'>
				<ItemShowcase title='Tile button'>
					<TileButton
						icon={icons.emptyCircle}
						label='Button'
						onClick={() => { }}
						noBottomSpacing
					/>
				</ItemShowcase>

				<CodeBlock
					language='jsx'
					code={`<TileButton
	icon={icons.emptyCircle}
	label='Button'
	onClick={() => {...}}
/>`}
				/>
			</div>
		</>
	);
};
