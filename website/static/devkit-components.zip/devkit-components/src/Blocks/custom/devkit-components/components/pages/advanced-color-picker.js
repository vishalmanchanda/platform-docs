import React, { useState } from 'react';
import { MarkdownView } from '../markdown-view';
import { ItemShowcase } from '../item-showcase';
import { AdvancedColorPicker } from '@eightshift/frontend-libs/scripts';
import { CodeBlock } from '../code-block';

export const AdvancedColorPickerDocs = () => {
	const stubGlobalManifest = {
		globalVariables: {
			colors: [
				{
					name: "Primary",
					slug: "primary",
					color: "#9973E3"
				},
				{
					name: "Black",
					slug: "black",
					color: "#000000"
				},
				{
					name: "Light",
					slug: "light",
					color: "#CCCCCC"
				}
			],
			gradients: [
				{
					name: "Gradient 1",
					slug: "gradient-1",
					gradient: "linear-gradient(90deg, #AB40FF 0%, #5D2BFF 100%)"
				}
			]
		}
	};

	const [type, setType] = useState('project');
	const [solidColor, setSolidColor] = useState(undefined);
	const [gradient, setGradient] = useState(undefined);
	const [projectColor, setProjectColor] = useState(undefined);

	const { globalVariables: { colors } } = stubGlobalManifest;

	const styleColors = colors.reduce((all, { slug, color }) => ({
		...all,
		[`--global-colors-${slug}`]: color,
	}), {});

	return (
		<>
			<MarkdownView
				content={`# Advanced color picker
				Component used to provide solid and gradient picker functionality to your component options.`}
			/>



			<div className='devkit-component-config' style={styleColors}>
				<ItemShowcase title='Basic control'>
					<AdvancedColorPicker
						type={type}
						colorProject={projectColor}
						colorSolid={solidColor}
						colorGradient={gradient}
						onChangeProject={(value) => {
							setProjectColor(value);
							setSolidColor(undefined);
							setGradient(undefined);
						}}
						onChangeSolid={(value) => {
							setProjectColor(undefined);
							setSolidColor(value);
							setGradient(undefined);
						}}
						onChangeGradient={(value) => {
							setProjectColor(undefined);
							setSolidColor(undefined);
							setGradient(value);
						}}
						onChangeType={(value) => setType(value)}
						globalManifest={stubGlobalManifest}
						noBottomSpacing
					/>
				</ItemShowcase>

				<CodeBlock
					language='jsx'
					code={`<AdvancedColorPicker
	type={type}
	colorProject={projectColor}
	colorSolid={solidColor}
	colorGradient={gradient}
	onChangeProject={(value) => {
		setProjectColor(value);
		setSolidColor(undefined);
		setGradient(undefined);
	}}
	onChangeSolid={(value) => {
		setProjectColor(undefined);
		setSolidColor(value);
		setGradient(undefined);
	}}
	onChangeGradient={(value) => {
		setProjectColor(undefined);
		setSolidColor(undefined);
		setGradient(value);
	}}
	onChangeType={(value) => setType(value)}
	globalManifest={stubGlobalManifest}
	noBottomSpacing
/>`}
				/>
			</div>

			<div className='devkit-component-config' style={styleColors}>
				<ItemShowcase title='Tile button' propsUsed={{ 'isTileButton': 'Render control as a Tile button' }}>
					<AdvancedColorPicker
						type={type}
						label='Color'
						colorProject={projectColor}
						colorSolid={solidColor}
						colorGradient={gradient}
						onChangeProject={(value) => {
							setProjectColor(value);
							setSolidColor(undefined);
							setGradient(undefined);
						}}
						onChangeSolid={(value) => {
							setProjectColor(undefined);
							setSolidColor(value);
							setGradient(undefined);
						}}
						onChangeGradient={(value) => {
							setProjectColor(undefined);
							setSolidColor(undefined);
							setGradient(value);
						}}
						onChangeType={(value) => setType(value)}
						globalManifest={stubGlobalManifest}
						isTileButton
					/>
				</ItemShowcase>

				<CodeBlock
					language='jsx'
					code={`<AdvancedColorPicker
	type={type}
	label='Color'
	colorProject={projectColor}
	colorSolid={solidColor}
	colorGradient={gradient}
	onChangeProject={(value) => {
		setProjectColor(value);
		setSolidColor(undefined);
		setGradient(undefined);
	}}
	onChangeSolid={(value) => {
		setProjectColor(undefined);
		setSolidColor(value);
		setGradient(undefined);
	}}
	onChangeGradient={(value) => {
		setProjectColor(undefined);
		setSolidColor(undefined);
		setGradient(value);
	}}
	onChangeType={(value) => setType(value)}
	globalManifest={stubGlobalManifest}
	isTileButton
/>`}
				/>
			</div>
		</>
	);
};
