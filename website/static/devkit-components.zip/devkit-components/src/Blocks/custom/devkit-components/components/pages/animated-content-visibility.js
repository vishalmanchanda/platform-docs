import React, { useState } from 'react';
import { MarkdownView } from '../markdown-view';
import { ItemShowcase } from '../item-showcase';
import { AnimatedContentVisibility } from '@eightshift/frontend-libs/scripts';
import { CodeBlock } from '../code-block';
import { Button } from '@wordpress/components';

export const AnimatedContentVisibilityDocs = () => {
	const [visible, setVisible] = useState(true);

	return (
		<>
			<MarkdownView
				content={`# AnimatedContentVisibility
				A wrapper around the Gutenberg \`Animated\` component, to make our components less boilerplate-y.`}
			/>

			<div className='devkit-component-config'>
				<ItemShowcase
					title='Base component'
					demoContainerClass='es-h-48'
					additionalPanels={[{
						title: 'Actions',
						content: (
							<Button
								onClick={() => setVisible(!visible)}
								// eslint-disable-next-line max-len
								className='es-w-14 es-content-center es-rounded-1.5! es-border-cool-gray-300 es-hover-border-cool-gray-500 es-hover-color-cool-gray-800! es-transition'
							>
								{visible ? 'Hide' : 'Show'}
							</Button>
						),
					}]}
				>
					<AnimatedContentVisibility showIf={visible}>
						<div className='es-h-40 es-w-full es-rounded-1 es-bg-cool-gray-100 es-display-flex es-items-center es-content-center'>
							Demo content
						</div>
					</AnimatedContentVisibility>
				</ItemShowcase>

				<CodeBlock
					language='jsx'
					code={`<AnimatedContentVisibility showIf={visible}>
	<div>Demo content</div>
</AnimatedContentVisibility>`}
				/>
			</div>
		</>
	);
};
