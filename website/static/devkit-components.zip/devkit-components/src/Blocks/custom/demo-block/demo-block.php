<?php

/**
 * Template for the Paragraph Block view.
 *
 * @package DevkitComponents
 */

use DevkitComponentsVendor\EightshiftLibs\Helpers\Components;

$globalManifest = Components::getManifest(dirname(__DIR__, 2));
$manifest = Components::getManifest(__DIR__);

$demoBlockText = Components::checkAttr('demoBlockText', $attributes, $manifest);
?>

<div class="es-p-3 es-bg-cool-gray-50 es-rounded-2 es-h-36 es-h-center">
	<?php
	// phpcs:ignore Eightshift.Security.ComponentsEscape.OutputNotEscaped
	echo $demoBlockText;
	?>
</div>
